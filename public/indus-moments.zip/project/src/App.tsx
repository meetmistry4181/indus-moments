import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import Layout from '@/components/Layout';
import AuthPage from '@/pages/AuthPage';
import PendingApproval from '@/pages/PendingApproval';
import HomePage from '@/pages/HomePage';
import EventsPage from '@/pages/EventsPage';
import EventDetailPage from '@/pages/EventDetailPage';
import UploadPage from '@/pages/UploadPage';
import FindPhotosPage from '@/pages/FindPhotosPage';
import GalleryPage from '@/pages/GalleryPage';
import ProfilePage from '@/pages/ProfilePage';
import AdminPage from '@/pages/AdminPage';

function Protected({ children }: { children: React.ReactNode }) { const { session, profile, loading, isApproved } = useAuth(); if (loading) return <div className="flex min-h-screen items-center justify-center bg-slate-50 text-sm text-slate-500">Loading Indus Moments...</div>; if (!session) return <Navigate to="/auth" replace />; if (!profile) return <div className="flex min-h-screen items-center justify-center bg-slate-50 text-sm text-slate-500">Preparing your account...</div>; if (!isApproved) return <PendingApproval />; return <Layout>{children}</Layout>; }
function AdminOnly({ children }: { children: React.ReactNode }) { const { isAdmin } = useAuth(); return isAdmin ? <>{children}</> : <Navigate to="/" replace />; }
function AppRoutes() { return <Routes><Route path="/auth" element={<AuthPage />} /><Route path="*" element={<Protected><Routes><Route path="/" element={<HomePage />} /><Route path="/events" element={<EventsPage />} /><Route path="/events/:id" element={<EventDetailPage />} /><Route path="/upload" element={<UploadPage />} /><Route path="/find-my-photos" element={<FindPhotosPage />} /><Route path="/gallery" element={<GalleryPage />} /><Route path="/profile" element={<ProfilePage />} /><Route path="/admin" element={<AdminOnly><AdminPage /></AdminOnly>} /><Route path="*" element={<Navigate to="/" replace />} /></Routes></Protected>} /></Routes>; }
export default function App() { return <BrowserRouter><AuthProvider><AppRoutes /></AuthProvider></BrowserRouter>; }
